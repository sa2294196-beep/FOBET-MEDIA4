import { MessageCircle } from "lucide-react";
import { WHATSAPP_LINK, WHATSAPP_DISPLAY } from "@/lib/contact";

export function WhatsAppFab() {
  return (
    <a
      href={WHATSAPP_LINK}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`Chat with Fobet Media on WhatsApp at ${WHATSAPP_DISPLAY}`}
      className="fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-full bg-whatsapp px-5 py-3.5 text-sm font-semibold text-background shadow-[0_10px_40px_oklch(0.72_0.17_152_/_0.45)] transition-transform hover:scale-105"
    >
      <MessageCircle className="size-5" />
      <span className="hidden sm:inline">WhatsApp Us</span>
    </a>
  );
}