import { useState, type FormEvent } from "react";
import { z } from "zod";
import { Send } from "lucide-react";
import { toast } from "sonner";

import { WHATSAPP_NUMBER } from "@/lib/contact";

const contactSchema = z.object({
  name: z
    .string()
    .trim()
    .nonempty({ message: "Please enter your name" })
    .max(100, { message: "Name must be less than 100 characters" }),
  email: z
    .string()
    .trim()
    .email({ message: "Enter a valid email address" })
    .max(255, { message: "Email must be less than 255 characters" }),
  phone: z
    .string()
    .trim()
    .regex(/^[0-9+\-\s()]{7,20}$/, { message: "Enter a valid phone number" }),
  message: z
    .string()
    .trim()
    .nonempty({ message: "Tell us a little about your brand" })
    .max(1000, { message: "Message must be less than 1000 characters" }),
});

type ContactValues = z.infer<typeof contactSchema>;
type FieldErrors = Partial<Record<keyof ContactValues, string>>;

const initialValues: ContactValues = { name: "", email: "", phone: "", message: "" };

const fields = [
  { name: "name", label: "Full name", placeholder: "Riya Upreti", type: "text", maxLength: 100 },
  { name: "email", label: "Email", placeholder: "you@company.com", type: "email", maxLength: 255 },
  { name: "phone", label: "Phone / WhatsApp", placeholder: "+91 90000 00000", type: "tel", maxLength: 20 },
] as const;

export function ContactForm() {
  const [values, setValues] = useState<ContactValues>(initialValues);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [submitting, setSubmitting] = useState(false);

  const update = (key: keyof ContactValues, value: string) => {
    setValues((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const onSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const result = contactSchema.safeParse(values);

    if (!result.success) {
      const next: FieldErrors = {};
      for (const issue of result.error.issues) {
        const key = issue.path[0] as keyof ContactValues;
        if (!next[key]) next[key] = issue.message;
      }
      setErrors(next);
      toast.error("Please fix the highlighted fields.");
      return;
    }

    setSubmitting(true);
    const { name, email, phone, message } = result.data;
    const text =
      `*New enquiry from Fobet Media website*\n\n` +
      `*Name:* ${name}\n` +
      `*Email:* ${email}\n` +
      `*Phone / WhatsApp:* ${phone}\n\n` +
      `*Message:*\n${message}\n\n` +
      `_Sent via fobetmedia.com contact form_`;
    window.open(
      `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`,
      "_blank",
      "noopener,noreferrer",
    );
    toast.success("Thanks! We're opening WhatsApp so you can send your enquiry.");
    setValues(initialValues);
    setSubmitting(false);
  };

  return (
    <form onSubmit={onSubmit} noValidate className="glass-card mt-10 rounded-3xl p-6 text-left sm:p-8">
      <div className="grid gap-5 sm:grid-cols-2">
        {fields.map((field) => (
          <div key={field.name} className={field.name === "phone" ? "sm:col-span-2" : ""}>
            <label htmlFor={field.name} className="text-sm font-semibold">
              {field.label}
            </label>
            <input
              id={field.name}
              name={field.name}
              type={field.type}
              maxLength={field.maxLength}
              placeholder={field.placeholder}
              value={values[field.name]}
              onChange={(e) => update(field.name, e.target.value)}
              aria-invalid={Boolean(errors[field.name])}
              aria-describedby={errors[field.name] ? `${field.name}-error` : undefined}
              className="mt-2 w-full rounded-xl border border-border bg-background/60 px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-ring/40"
            />
            {errors[field.name] && (
              <p id={`${field.name}-error`} className="mt-2 text-xs text-destructive">
                {errors[field.name]}
              </p>
            )}
          </div>
        ))}

        <div className="sm:col-span-2">
          <label htmlFor="message" className="text-sm font-semibold">
            What do you want to build?
          </label>
          <textarea
            id="message"
            name="message"
            rows={4}
            maxLength={1000}
            placeholder="Tell us about your brand, niche and goals."
            value={values.message}
            onChange={(e) => update("message", e.target.value)}
            aria-invalid={Boolean(errors.message)}
            aria-describedby={errors.message ? "message-error" : undefined}
            className="mt-2 w-full resize-y rounded-xl border border-border bg-background/60 px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-ring/40"
          />
          <div className="mt-2 flex items-center justify-between gap-3">
            {errors.message ? (
              <p id="message-error" className="text-xs text-destructive">
                {errors.message}
              </p>
            ) : (
              <span className="text-xs text-muted-foreground">Max 1000 characters</span>
            )}
            <span className="text-xs text-muted-foreground">{values.message.length}/1000</span>
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={submitting}
        className="glow-brand mt-7 inline-flex w-full items-center justify-center gap-2 rounded-full bg-brand px-8 py-4 font-semibold text-primary-foreground transition-transform hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-60"
      >
        <Send className="size-4" />
        {submitting ? "Sending..." : "Request a Call"}
      </button>
      <p className="mt-3 text-center text-xs text-muted-foreground">
        Your information is secure and will never be shared.
      </p>
    </form>
  );
}