import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, Check, ChevronDown, MessageCircle, Play, Sparkles } from "lucide-react";

import heroFounder from "@/assets/hero-founder.jpg";
import btsStudio from "@/assets/bts-studio.jpg";
import { WhatsAppFab } from "@/components/site/WhatsAppFab";
import { ContactForm } from "@/components/site/ContactForm";
import { WHATSAPP_DISPLAY, WHATSAPP_LINK } from "@/lib/contact";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Fobet Media | Personal Branding Agency" },
      {
        name: "description",
        content:
          "Done-for-you personal branding and short-form video agency. Scripting, shooting, editing and posting — you show up just 2 days a month.",
      },
      { property: "og:title", content: "Fobet Media | Personal Branding Agency" },
      {
        property: "og:description",
        content:
          "Scale your authority with a done-for-you personal branding agency. 500M+ views generated. Chat with us on WhatsApp.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const nav = [
  { label: "Home", href: "#home" },
  { label: "Stats", href: "#stats" },
  { label: "Results", href: "#results" },
  { label: "Protocol", href: "#protocol" },
  { label: "Packages", href: "#packages" },
  { label: "FAQ", href: "#faq" },
  { label: "About Us", href: "#team" },
];

const stats = [
  { value: "10M+", label: "Revenue Generated" },
  { value: "50M+", label: "Followers Built" },
  { value: "500M+", label: "Views Generated" },
];

const results = [
  { handle: "@mehakmarketing", headline: "Fastest 100K", sub: "in the industry", months: "4 months with us" },
  { handle: "@drmayankofficial", headline: "150K+ Followers", sub: "in just 4 months", months: "4 months with us" },
  { handle: "@mazedarfinance", headline: "70K+ Followers", sub: "from zero", months: "3 months with us" },
];

const protocol = [
  { n: "01", t: "Deep-Dive Research", d: "We analyze your competitors, niche gaps and viral patterns to build a data-backed content strategy." },
  { n: "02", t: "Viral Scripting", d: "25–30 psychologically hooked scripts every month, designed to stop the scroll and retain viewers." },
  { n: "03", t: "Guided Shooting", d: "You record for just 2 days a month. We provide direction, shot lists and real-time guidance." },
  { n: "04", t: "High-Retention Editing", d: "Sharp pacing, captions and b-roll applied by editors obsessed with watch time." },
  { n: "05", t: "Strategic Posting", d: "Upload, hashtags, SEO optimisation and timing handled to hit the algorithm perfectly." },
  { n: "06", t: "Growth Management", d: "We manage your community, reply to comments and nurture leads through DM automation." },
];

const packages = [
  {
    name: "1:1 Mentorship Session",
    price: "₹45,000",
    period: "",
    blurb: "A direct clarity session to fix your brand direction.",
    features: [
      "Brand positioning: who you are & how people see you",
      "Clear content pillars & storytelling style",
      "Exact audience & niche clarity",
      "6-month growth roadmap",
      "Script & hook structuring",
      "Page audit and monetisation plan",
    ],
    featured: false,
  },
  {
    name: "Complete Creator Growth",
    price: "₹4,00,000",
    period: "/month",
    blurb: "Done-for-you creator growth. You just show up.",
    features: [
      "Strategy, scripting, shooting, editing, posting",
      "25–30 scripts written every month",
      "2 studio shoot days a month",
      "Community & DM management",
      "Minimum guarantee included — miss the agreed goals, get a full refund",
    ],
    featured: true,
  },
  {
    name: "Flagship — Fobet 2.0",
    price: "₹7,50,000",
    period: "/month",
    blurb: "Organic + paid media growth system for founders ready to scale.",
    features: [
      "Everything in Complete Creator Growth",
      "Meta Ads strategy, setup and management",
      "Audience research, targeting and funnel mapping",
      "A/B testing for hooks, creatives and offers",
      "Pixel, conversion tracking and ROAS optimisation",
      "Ad-spend management up to ₹10 lakh/month",
    ],
    featured: false,
  },
];

const faqs = [
  {
    q: "I don't have time to shoot content every week. How will this work?",
    a: "You don't have to. We shoot all your reels for the month in just two dedicated studio days. Everything from setup to direction is handled by our team.",
  },
  {
    q: "I'm not good on camera. Will I still be able to do this?",
    a: "Absolutely. You don't need to remember lines or act. Our prompt director guides you line by line during the shoot. Most clients had zero on-camera experience before starting.",
  },
  {
    q: "I don't know what to talk about or what will work for me.",
    a: "That's our job. We research your niche, competitors and audience, then create 25–30 targeted scripts every month, all aligned with your goals.",
  },
  {
    q: "Will this actually get me followers or just good-looking videos?",
    a: "Our focus is growth, not aesthetics. Every script, hook and call-to-action is designed for reach, engagement and conversion.",
  },
  {
    q: "How involved do I have to be?",
    a: "You only need to be present for the 2 shoot days each month. Our team handles scripting, directing, editing, posting and strategy.",
  },
  {
    q: "What is the minimum guarantee?",
    a: "If we don't help you reach 100K followers within 6 months, we keep working for 2 extra months free. If we still miss it, every rupee is refunded.",
  },
];

const team = [
  {
    role: "Founder",
    name: "Riya Upreti",
    bio: "The creative force. Riya understands audience psychology better than anyone and bridges raw emotion with strategic content.",
  },
  {
    role: "Co-Founder",
    name: "Vibhav Raj",
    bio: "The strategist. An engineering grad who treats virality as a science to be engineered, not guessed.",
  },
];

function Index() {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-xl">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
          <a href="#home" className="flex items-center gap-2.5">
            <span className="grid size-9 place-items-center rounded-xl bg-brand text-sm font-bold text-primary-foreground">
              fm
            </span>
            <span className="text-sm font-bold tracking-[0.18em] uppercase">Fobet Media</span>
          </a>
          <ul className="hidden items-center gap-7 lg:flex">
            {nav.map((item) => (
              <li key={item.label}>
                <a
                  href={item.href}
                  className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-brand px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-transform hover:scale-105"
          >
            Get Started <ArrowRight className="size-4" />
          </a>
        </nav>
      </header>

      <main>
        {/* Hero */}
        <section id="home" className="aurora relative overflow-hidden">
          <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-20 lg:grid-cols-2 lg:py-28">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-4 py-2 text-xs font-semibold tracking-[0.18em] uppercase">
                <Sparkles className="size-3.5 text-primary" /> Fobet Media
              </span>
              <h1 className="mt-6 text-5xl leading-[1.05] font-extrabold sm:text-6xl lg:text-7xl">
                We make your business{" "}
                <span className="text-gradient">impossible to ignore.</span>
              </h1>
              <p className="mt-6 max-w-lg text-lg text-muted-foreground">
                Done-for-you personal branding agency that converts strangers into customers. We
                position you as the authority in your niche.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <a
                  href={WHATSAPP_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="glow-brand inline-flex items-center gap-2 rounded-full bg-brand px-7 py-3.5 font-semibold text-primary-foreground transition-transform hover:scale-105"
                >
                  Start Growing Now <ArrowRight className="size-4" />
                </a>
                <a
                  href="#results"
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-7 py-3.5 font-semibold transition-colors hover:bg-card"
                >
                  <Play className="size-4" /> See Results
                </a>
              </div>
            </div>

            <div className="relative">
              <div className="glass-card overflow-hidden rounded-[2.5rem]">
                <img
                  src={heroFounder}
                  alt="Fobet Media co-founder Vibhav Raj during a studio session"
                  width={1024}
                  height={1280}
                  className="h-full w-full object-cover"
                />
              </div>
              <div className="glass-card absolute -left-3 top-10 rounded-full px-4 py-2 text-xs font-semibold sm:text-sm">
                Personal Branding Experts
              </div>
              <div className="glass-card absolute -right-3 bottom-24 rounded-full px-4 py-2 text-xs font-semibold sm:text-sm">
                Scaled 70+ clients to 7 figures
              </div>
            </div>
          </div>
        </section>

        {/* Stats */}
        <section id="stats" className="border-y border-border bg-card/30">
          <div className="mx-auto max-w-7xl px-5 py-20 text-center">
            <span className="text-xs font-semibold tracking-[0.22em] text-primary uppercase">
              Done for you services
            </span>
            <h2 className="mt-4 text-4xl font-extrabold sm:text-5xl">Just 2 days in a month</h2>
            <p className="mt-3 text-muted-foreground">
              for creating impactful personal brands — revenue, followers and massive reach.
            </p>
            <div className="mt-12 grid gap-5 sm:grid-cols-3">
              {stats.map((s) => (
                <div key={s.label} className="glass-card rounded-3xl p-8">
                  <div className="text-gradient text-4xl font-extrabold sm:text-5xl">{s.value}</div>
                  <div className="mt-2 text-sm text-muted-foreground">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Results */}
        <section id="results" className="mx-auto max-w-7xl px-5 py-24">
          <div className="text-center">
            <span className="text-xs font-semibold tracking-[0.22em] text-primary uppercase">
              Proven results
            </span>
            <h2 className="mt-4 text-4xl font-extrabold sm:text-5xl">
              Client <span className="text-gradient">transformation results</span>
            </h2>
            <p className="mt-3 text-muted-foreground">
              We work with business owners, entrepreneurs and professionals.
            </p>
          </div>
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {results.map((r) => (
              <article key={r.handle} className="glass-card rounded-3xl p-7">
                <div className="text-xs font-semibold tracking-wide text-primary">
                  Milestone unlocked
                </div>
                <div className="mt-3 text-sm text-muted-foreground">{r.handle}</div>
                <h3 className="mt-2 text-3xl font-extrabold">{r.headline}</h3>
                <p className="mt-1 text-muted-foreground">{r.sub}</p>
                <div className="mt-6 inline-flex rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">
                  {r.months}
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* Protocol */}
        <section id="protocol" className="border-y border-border bg-card/30">
          <div className="mx-auto max-w-7xl px-5 py-24">
            <div className="text-center">
              <span className="text-xs font-semibold tracking-[0.22em] text-primary uppercase">
                Systematized growth
              </span>
              <h2 className="mt-4 text-4xl font-extrabold sm:text-5xl">
                Our proven <span className="text-gradient">branding protocol</span>
              </h2>
              <p className="mt-3 text-muted-foreground">
                We don't guess. We follow a proven, repeatable process to scale your brand.
              </p>
            </div>
            <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {protocol.map((p) => (
                <div key={p.n} className="glass-card rounded-3xl p-7">
                  <span className="text-gradient text-4xl font-extrabold">{p.n}</span>
                  <h3 className="mt-4 text-xl font-bold">{p.t}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{p.d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* BTS */}
        <section className="mx-auto max-w-7xl px-5 py-24">
          <div className="glass-card grid items-center gap-10 overflow-hidden rounded-[2.5rem] p-8 lg:grid-cols-2 lg:p-12">
            <div>
              <span className="text-xs font-semibold tracking-[0.22em] text-primary uppercase">
                Behind the magic
              </span>
              <h2 className="mt-4 text-4xl font-extrabold">
                Behind the <span className="text-gradient">scenes</span>
              </h2>
              <p className="mt-4 text-muted-foreground">
                A full production crew, studio lighting, prompt direction and post-production — all
                packed into two shoot days a month so you never have to think about content again.
              </p>
            </div>
            <img
              src={btsStudio}
              alt="Fobet Media studio set with camera and neon lighting"
              width={1280}
              height={800}
              loading="lazy"
              className="w-full rounded-3xl object-cover"
            />
          </div>
        </section>

        {/* Packages */}
        <section id="packages" className="border-y border-border bg-card/30">
          <div className="mx-auto max-w-7xl px-5 py-24">
            <div className="text-center">
              <span className="text-xs font-semibold tracking-[0.22em] text-primary uppercase">
                Pricing plans
              </span>
              <h2 className="mt-4 text-4xl font-extrabold sm:text-5xl">
                Our <span className="text-gradient">packages</span>
              </h2>
              <p className="mt-3 text-muted-foreground">
                Build organic authority, or combine it with a paid media acquisition engine.
              </p>
            </div>
            <div className="mt-12 grid items-start gap-6 lg:grid-cols-3">
              {packages.map((p) => (
                <div
                  key={p.name}
                  className={`glass-card rounded-3xl p-8 ${p.featured ? "glow-brand border-primary/50 lg:-mt-4 lg:pb-12" : ""}`}
                >
                  {p.featured && (
                    <span className="mb-4 inline-flex rounded-full bg-brand px-3 py-1 text-xs font-bold text-primary-foreground">
                      Most popular
                    </span>
                  )}
                  <h3 className="text-xl font-bold">{p.name}</h3>
                  <div className="mt-4 flex items-end gap-1">
                    <span className="text-gradient text-4xl font-extrabold">{p.price}</span>
                    <span className="pb-1 text-sm text-muted-foreground">{p.period}</span>
                  </div>
                  <p className="mt-3 text-sm text-muted-foreground">{p.blurb}</p>
                  <ul className="mt-6 space-y-3">
                    {p.features.map((f) => (
                      <li key={f} className="flex gap-3 text-sm">
                        <Check className="mt-0.5 size-4 shrink-0 text-primary" />
                        <span className="text-muted-foreground">{f}</span>
                      </li>
                    ))}
                  </ul>
                  <a
                    href={WHATSAPP_LINK}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`mt-8 inline-flex w-full items-center justify-center gap-2 rounded-full px-6 py-3 font-semibold transition-transform hover:scale-[1.02] ${
                      p.featured
                        ? "bg-brand text-primary-foreground"
                        : "border border-border bg-card/60"
                    }`}
                  >
                    Get Started <ArrowRight className="size-4" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section id="faq" className="mx-auto max-w-4xl px-5 py-24">
          <div className="text-center">
            <span className="text-xs font-semibold tracking-[0.22em] text-primary uppercase">
              Got questions?
            </span>
            <h2 className="mt-4 text-4xl font-extrabold sm:text-5xl">
              Frequently asked <span className="text-gradient">questions</span>
            </h2>
          </div>
          <div className="mt-10 space-y-3">
            {faqs.map((f, i) => (
              <div key={f.q} className="glass-card overflow-hidden rounded-2xl">
                <button
                  type="button"
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  aria-expanded={openFaq === i}
                  className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left font-semibold"
                >
                  {f.q}
                  <ChevronDown
                    className={`size-5 shrink-0 text-primary transition-transform ${openFaq === i ? "rotate-180" : ""}`}
                  />
                </button>
                {openFaq === i && (
                  <p className="px-6 pb-5 text-sm text-muted-foreground">{f.a}</p>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Team */}
        <section id="team" className="border-y border-border bg-card/30">
          <div className="mx-auto max-w-5xl px-5 py-24">
            <div className="text-center">
              <span className="text-xs font-semibold tracking-[0.22em] text-primary uppercase">
                Meet the minds
              </span>
              <h2 className="mt-4 text-4xl font-extrabold sm:text-5xl">
                Our <span className="text-gradient">leadership</span>
              </h2>
              <p className="mt-3 text-muted-foreground">
                Strategy, creativity and execution — the team behind the screens.
              </p>
            </div>
            <div className="mt-12 grid gap-6 md:grid-cols-2">
              {team.map((m) => (
                <div key={m.name} className="glass-card rounded-3xl p-8">
                  <span className="text-xs font-semibold tracking-[0.2em] text-primary uppercase">
                    {m.role}
                  </span>
                  <h3 className="mt-3 text-2xl font-bold">{m.name}</h3>
                  <p className="mt-3 text-sm text-muted-foreground">{m.bio}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact */}
        <section id="contact" className="aurora">
          <div className="mx-auto max-w-3xl px-5 py-24 text-center">
            <span className="text-xs font-semibold tracking-[0.22em] text-primary uppercase">
              Get in touch
            </span>
            <h2 className="mt-4 text-4xl font-extrabold sm:text-5xl">
              Ready to <span className="text-gradient">scale?</span>
            </h2>
            <p className="mt-4 text-muted-foreground">
              Have questions about our packages or want to see if we're a good fit? We're available
              24/7 on WhatsApp.
            </p>

            <ContactForm />

            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-whatsapp px-8 py-4 font-semibold text-background transition-transform hover:scale-105"
            >
              <MessageCircle className="size-5" /> Prefer chat? Message us
            </a>
            <p className="mt-4 text-sm text-muted-foreground">
              WhatsApp: <span className="font-semibold text-foreground">{WHATSAPP_DISPLAY}</span>
            </p>
          </div>
        </section>
      </main>

      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-5 py-8 sm:flex-row">
          <span className="text-sm font-bold tracking-[0.18em] uppercase">Fobet Media</span>
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Fobet Media. All rights reserved.
          </p>
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            {WHATSAPP_DISPLAY}
          </a>
        </div>
      </footer>

      <WhatsAppFab />
    </div>
  );
}
